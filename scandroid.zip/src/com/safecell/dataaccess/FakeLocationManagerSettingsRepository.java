package com.safecell.dataaccess;

public class FakeLocationManagerSettingsRepository {
	
 static final String CREATE_TABLE_QUERY = "CREATE TABLE fake_location_manager_settings (id INTEGER PRIMARY KEY  NOT NULL ,item TEXT NOT NULL ,value TEXT";

}
