package com.safecell.dataaccess;

public class AbstractRepository {

}
