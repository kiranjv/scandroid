package com.safecell.utilities;

public class URLs {

	// public static String REMOTE_URL = "http://safecell-test.heroku.com/";

	// public static String REMOTE_URL = "http://my.safecellapp.com/";

	public static String REMOTE_URL = "http://www.safecellapp.mobi/";
	public static String CONFIG_URL = "http://www.safecellapp.mobi/api/1/configcompany/";
	public static String EMERGENCY_URL = "http://www.safecellapp.mobi/api/1/emergencynum/";
	public static String FAX_URL = "http://www.safecellapp.mobi/api/1/site_setting/androidfaqs.html";
//	public static String REMOTE_URL = "http://192.168.1.102:3000/";
//	public static String CONFIG_URL = "http://192.168.1.102:3000/api/1/configcompany/";
//	public static String EMERGENCY_URL = "http://192.168.1.102:3000/api/1/emergencynum/";

	// public static String REMOTE_URL = "http://192.168.2.9:3000/";
	// public static String REMOTE_URL = "http://localhost:3000/";

	// Test URL

	// http://www.safecellapp.mobi/api/1/emergencynum/41299

	// public static String CONFIG_URL =
	// "http://localhost:3000/api/1/configcompany/";
	// public static String EMERGENCY_URL =
	// "http://localhost:3000/api/1/emergencynum/";

	// public static String CONFIG_URL =
	// "http://192.168.2.9:3000/api/1/configcompany/";

}
