package com.safecell.model;

public class SCJournyLogItem {

}
