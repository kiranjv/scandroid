package com.safecell.model;

public class SCFakeLocation {

	String fileName;
	String estimatedSpeed;
	String longitude;
	String timeStamp;
	String latitude;
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getEstimatedSpeed() {
		return estimatedSpeed;
	}
	public void setEstimatedSpeed(String estimatedSpeed) {
		this.estimatedSpeed = estimatedSpeed;
	}
	public String getLongitude() {
		return longitude;
	}
	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}
	public String getTimeStamp() {
		return timeStamp;
	}
	public void setTimeStamp(String timeStamp) {
		this.timeStamp = timeStamp;
	}
	public String getLatitude() {
		return latitude;
	}
	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}
}
